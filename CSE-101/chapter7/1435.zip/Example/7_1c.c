#include<stdio.h>

int main()
{

    double answer;
    answer=sqrt(9.0);
    printf("%lf",answer);

    return 0;
}